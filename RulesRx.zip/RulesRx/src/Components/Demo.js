import React from 'react'  
import NavSideBar from '../Navbar/NavSideBar'
import Coverage from '../PbmRules/Coverage/Coverage'

class Demo extends React.Component {  
  render() {  
    return <div>
  

      <Coverage />

     
    </div>  
  }  
}  
export default Demo  