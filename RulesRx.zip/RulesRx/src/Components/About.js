import React from 'react'  
import { Button,Table } from 'react-bootstrap';
import './About.css'


class About extends React.Component {  
  render() {  
    return <div>About
<hr/>
<Table   hover >
  <thead >
    <tr>
    <th></th>
      <th> Name</th>
      <th>Start Data</th>
      <th>End Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>AndrewTest12345</a></td>
      <td>2021-12-23</td>
      <td>2021-12-30</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>AndrewTesting</a></td>
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>AndrewTesting New</a></td>
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Greg Generic Rule</a></td>
      <td>2021-12-01</td>
      <td>2022-12-31</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Greg Test Rule</a></td>
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>Meds Male 60</a></td>
      <td>2021-12-01</td>
      <td>2022-12-31</td>
    </tr>
  
 
  
    
    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'>Larry the Bird</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
  </tbody>
</Table>
      
    </div>  
  }  
}  
export default About  