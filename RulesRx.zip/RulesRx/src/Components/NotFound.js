import React from 'react'

export default function NotFound() {
    return (
        <div>
           Page NOT Found
        </div>
    )
}

