
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Demo from './Components/Demo';
import Contact from './Components/Contact';
import About from './Components/About';
import NotFound from './Components/NotFound';
import NavSideBar from './Navbar/NavSideBar';
import Result from './Results/Result';
import Products from './Products/Products';
import Druglists from './ListRules/Druglists';
import AttributesRule from './Attributes/AttributesRule/AttributesRule';
import DemoPage from './DemoPage';
import SideBarData from './Navbar/SideBarData';



function Routes1() {
  return (


    <Router>
      
         <nav>
           
        {/* <ul>
       
          <li><a href="/">Home</a></li>
          <li><a href="/Contact">Contact</a></li>
          <li><a href="/About">About</a></li>
        </ul> */}
        {/* <NavSideBar /> */}

        {/* <div style={{ position: 'relative', zIndex: '1' }}> */}
        <div>
 {/* <NavSideBar /> */}
 <SideBarData />

      </div>
      </nav>
  <div style={{ paddingLeft:"70px", paddingRight:"10px" }} >

      <Routes>
        <Route exact path="/" element={<Demo/>}/>
        <Route exact path="/Contact" element={<Contact/>}/>
        <Route exact path="/About" element={<About/>}/>
        <Route exact path="/Result" element={<Result/>}/>
        <Route exact path="/Products" element={<Products/>}/>
        <Route exact path="/Druglists" element={<Druglists/>}/>
        <Route exact path="/AttributesRule" element={<AttributesRule/>}/>
        <Route exact path="/DemoPage" element={<DemoPage/>}/>


        <Route path="*" element={<NotFound/>}/>
      </Routes>
  
  </div>
  </Router>
  );
}

export default Routes1;
