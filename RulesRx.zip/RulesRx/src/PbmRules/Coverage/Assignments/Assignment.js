import React, { Component } from 'react'
import { Button, Row, Col, FormGroup, Label, Input, Modal,handleClose ,Form, Card, CardBody, CardText, CardTitle, CardSubtitle } from 'reactstrap';
import './Assignment.css';


export default class Assignment extends Component {
    constructor(props) {
        super(props)

        this.state = {
            isToggleOn: true,
            value: ""
        }
    }



    AddruleHandler = () => {
        this.setState(prevState => ({
            isToggleOn: !prevState.isToggleOn
        }));
    }

    ButtonMuteHandler = () => {
        this.setState({
            value: "true"
        });
    }
    render() {
        return (
            <div>
                &nbsp; &nbsp; &nbsp;  Assignment Page








                <Card
                >
                    <CardBody>

                        <Form>
                            <FormGroup row>
                                <Col sm={3}>
                                    <Label for="exampleSelect">
                                        Client:
                                    </Label>
                                    <Input
                                        id="exampleSelect"
                                        name="select"
                                        type="select"
                                    >
                                        <option>

                                        </option>
                                        <option>
                                            FB
                                        </option>
                                        <option>
                                            GOOGLE
                                        </option>
                                        <option>
                                            AMEX
                                        </option>
                                        <option>
                                            GLOBAL
                                        </option>
                                        <option>
                                            USNAVY
                                        </option>
                                        <option>
                                            CASH_NETWORK
                                        </option>
                                    </Input>

                                </Col>
                                <Col sm={3}>
                                    <Label for="exampleSelect">
                                        Benefit:
                                    </Label>
                                    <Input
                                        id="exampleSelect"
                                        name="select"
                                        type="select"
                                    >
                                        <option>

                                        </option>
                                        <option>
                                            111111
                                        </option>
                                        <option>
                                            123456
                                        </option>
                                        <option>
                                            654321
                                        </option>
                                        <option>
                                            333333
                                        </option>
                                    </Input>
                                </Col>
                            </FormGroup>

                            <FormGroup row>
                                <Col sm={3}>
                                    <Label for="exampleSelect">
                                        Rule List:
                                    </Label>
                                    <Input
                                        id="exampleSelect"
                                        name="select"
                                        type="select"
                                        onClick={this.ButtonMuteHandler} >
                                        <option>

                                        </option>
                                        <option>
                                            Dev Test Menu
                                        </option>
                                        <option>
                                            Cash Network Test Menu
                                        </option>
                                        <option>
                                            Test
                                        </option>
                                        <option>
                                            Test Menu
                                        </option>
                                        <option>
                                            Google Test Menu
                                        </option>
                                        <option>
                                            Cash Network 10k Test Menu
                                        </option>
                                        <option>
                                            Cash Network 20k Test Menu
                                        </option>
                                    </Input>

                                </Col>
                                <Col sm={2}>
                                    <Label for="exampleDate">
                                        Effective:
                                    </Label>
                                    <Input
                                        id="exampleDate"
                                        name="date"
                                        placeholder="date placeholder"
                                        type="date"
                                    />
                                </Col>
                            </FormGroup>

                            <FormGroup row>
                                <div className="error">
                                    <Col sm={4}>

                                        <Button disabled={!this.state.value} onClick={this.AddruleHandler}> <b>{this.state.isToggleOn ? 'Add Rule' : 'Cancel'}</b></Button>

                                    </Col>
                                </div>
                                <Col sm={2}>

                                </Col>
                            </FormGroup>

                        </Form>

                        <div id="myDIV" style={{ display: `${this.state.isToggleOn ? 'none' : ''}` }} >

                            <Form>


                                <FormGroup row>
                                    <Col sm={2}>
                                        <Label for="exampleSelect">
                                            &nbsp; Order
                                        </Label>

                                        &nbsp; <h2>276673</h2>

                                    </Col>
                                    <Col sm={3}>
                                        <Label for="exampleSelect">
                                            Rule
                                        </Label>
                                        <Input
                                            id="exampleSelect"
                                            name="select"
                                            type="select"
                                        >
                                            <option>
                                                test_rule
                                            </option>
                                            <option>
                                                test_rule
                                            </option>
                                            <option>
                                                test_rule
                                            </option>
                                            <option>
                                                test_rule
                                            </option>

                                        </Input>

                                    </Col>
                                    <Col sm={2}>
                                        <Label for="exampleSelect">
                                            Result:
                                        </Label>
                                        <Input
                                            id="exampleSelect"
                                            name="select"
                                            type="select"
                                        >
                                            <option>
                                                Covered
                                            </option>
                                            <option>
                                                Not Covered
                                            </option>
                                            <option>
                                                PA Required
                                            </option>
                                        </Input>
                                    </Col>
                                    <Col sm={2}>
                                        <Label for="exampleSelect">
                                            Secondary Message
                                        </Label>
                                        <Input
                                            id="exampleSelect"
                                            name="select"
                                            type="text"
                                        >

                                        </Input>
                                    </Col>
                                    <Col sm={3}>

                                        <Button className='saveBtn'><b>Save</b></Button>
                                    </Col>
                                </FormGroup>
                            </Form>

                        </div>


                    </CardBody>
                </Card>



            </div>
        )
    }
}
