import React from 'react'  
import { InputGroup,FormControl ,Button, Modal,Dropdown,ButtonGroup, Table} from 'react-bootstrap';
import {  Row, Col, FormText ,FormGroup, Label, Input, Form, Card, CardBody, CardText, CardTitle, CardSubtitle } from 'reactstrap';


import './Rules.css'


class Rules extends React.Component {  
  state = {
    isOpen: false
  };

  openModal = () => this.setState({ isOpen: true });
  closeModal = () => this.setState({ isOpen: false });

  render() {  
    return <div>Rules: Coverage

{/* <div
          className="d-flex align-items-center justify-content-center"
       
        >
          <Button variant="primary" onClick={this.openModal}>
            click here
          </Button>
        </div> */}
        <Modal show={this.state.isOpen} onHide={this.closeModal}>
          <Modal.Header closeButton  style={{backgroundColor:"#14568d"}}>
          
          </Modal.Header>

          <Form style={{padding:"15px"}} >
            <p style={{fontSize: "50px"}}>Rule</p>
            <hr/>
  <FormGroup row>
    <Label
      for="exampleEmail"
      sm={3}
    >
      Name:
    </Label>
    <Col sm={8}>
      <Input
        id="exampleName"
        name="text"
        placeholder="Enter Name"
        type="text"
      />
    </Col>
  </FormGroup>
  <FormGroup row>
    <Label
      for="examplePassword"
      sm={3}
    >
      Product:
    </Label>
    <Col sm={8}>
    <Input
                                        id="exampleSelect"
                                        name="select"
                                        type="select"
                                        onClick={this.ButtonMuteHandler} >
                                        <option>

                                        </option>
                                        <option>
                                            Dev Test Menu
                                        </option>
                                        <option>
                                            Cash Network Test Menu
                                        </option>
                                        <option>
                                            Test
                                        </option>
                                        <option>
                                            Test Menu
                                        </option>
                                        <option>
                                            Google Test Menu
                                        </option>
                                        <option>
                                            Cash Network 10k Test Menu
                                        </option>
                                        <option>
                                            Cash Network 20k Test Menu
                                        </option>
                                    </Input>
    </Col>
  </FormGroup>
  <FormGroup row>
    <Label
      for="examplePassword"
      sm={3}
    >
      Start Date
    </Label>
    <Col sm={5}>
  
                                    <Input
                                        id="exampleDate"
                                        name="date"
                                        placeholder="date placeholder"
                                        type="date"
                                    />
    </Col>
  </FormGroup>

  <FormGroup row>
    <Label
      for="examplePassword"
      sm={3}
    >
      End Date
    </Label>
    <Col sm={5}>
  
                                    <Input
                                        id="exampleDate"
                                        name="date"
                                        placeholder="date placeholder"
                                        type="date"
                                    />
    </Col>
  </FormGroup>


</Form>

         
          <Modal.Footer >
            <Button    style={{backgroundColor: "#009BDF" , marginRight:"150px", padding:"10px 40px"}}  onClick={this.closeModal}>
          <b>
          Confirm
            </b>   
            </Button>
          </Modal.Footer>
        </Modal>
        <br/> <br/>




<InputGroup>  
    <FormControl 
     className='mainLoginInput' placeholder=" &#61442; Search by rule name"
      aria-label="Recipient's username with two button addons"
    />
    
    <Dropdown as={ButtonGroup}>
  <Button className='search' ><b>Search</b></Button>

  <Dropdown.Toggle className='searchIcon' split variant="primary" id="dropdown-split-basic" />

  <Dropdown.Menu >
    <Dropdown.Item href="#/action-1" onClick={this.openModal}>Add</Dropdown.Item>
    <Dropdown.Item href="#/action-2" >Edit</Dropdown.Item>
    <Dropdown.Item href="#/action-3">Copy</Dropdown.Item>
    <Dropdown.Item href="#/action-4">Delete</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>
  </InputGroup>



  <Card
            >
                <CardBody>

                    <Form>
<Table   hover >
  <thead >
    <tr>
    <th></th>
      <th> Name</th>
      <th>Start Data</th>
      <th>End Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>AndrewTest12345</a></td>
      <td>2021-12-23</td>
      <td>2021-12-30</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>AndrewTesting</a></td>
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>AndrewTesting New</a></td>
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Greg Generic Rule</a></td>
      <td>2021-12-01</td>
      <td>2022-12-31</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Greg Test Rule</a></td>
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>Meds Male 60</a></td>
      <td>2021-12-01</td>
      <td>2022-12-31</td>
    </tr>
  
 
  
    
    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'>Larry the Bird</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>2021-11-26</td>
      <td>2021-12-01</td>
    </tr>
  </tbody>
</Table>
</Form>
</CardBody>
</Card>
      
    </div>  
  }  
}  
export default Rules  