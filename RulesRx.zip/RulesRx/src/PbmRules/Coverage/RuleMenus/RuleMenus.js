import React, { Component } from 'react'
import {  Row, Col, FormGroup, Label, Input, Form, Card, CardBody, CardText, CardTitle, CardSubtitle } from 'reactstrap';
import { InputGroup,FormControl ,Button ,Modal,Dropdown,ButtonGroup, Table} from 'react-bootstrap';
import './RuleMenus.css'
import { Link } from 'react-router-dom';

export default class RuleMenus extends Component {
  state = {
    isOpen: false
  };

  openModal = () => this.setState({ isOpen: true });
  closeModal = () => this.setState({ isOpen: false });

    render() {
        return (
            <div>
          



          <Modal show={this.state.isOpen} onHide={this.closeModal}>
          <Modal.Header closeButton  style={{backgroundColor:"#14568d"}}>
          
          </Modal.Header>

          <Form style={{padding:"15px"}} >
            <p style={{fontSize: "50px"}}>Rule Menus</p>
            <hr/>
  <FormGroup row>
    <Label
      for="exampleEmail"
      sm={3}
    >
      Name:
    </Label>
    <Col sm={8}>
      <Input
        id="exampleName"
        name="text"
        placeholder="Enter Name"
        type="text"
      />
    </Col>
  </FormGroup>
  <FormGroup row>
    <Label
      for="examplePassword"
      sm={3}
    >
      Client:
    </Label>
    <Col sm={6}>
    <Input
                                        id="exampleSelect"
                                        name="select"
                                        type="select"
                                        onClick={this.ButtonMuteHandler} >
                                        <option>

                                        </option>
                                        <option>
                                            FB
                                        </option>
                                        <option>
                                            GOOGLE
                                        </option>
                                        <option>
                                            AMEX
                                        </option>
                                        <option>
                                           GLOBAL
                                        </option>
                                        <option>
                                           USNAVY
                                        </option>
                                        <option>
                                           CASH_NETWORK
                                        </option>
                                       
                                    </Input>
    </Col>
  </FormGroup>

  <FormGroup row>
    <Label
      for="examplePassword"
      sm={3}
    >
      Product:
    </Label>
    <Col sm={6}>
    <Input
                                        id="exampleSelect"
                                        name="select"
                                        type="select"
                                        onClick={this.ButtonMuteHandler} >
                                        <option>

                                        </option>
                                        <option>
                                            Dev Test Productx
                                        </option>
                                        <option>
                                           CN Test
                                        </option>
                                        <option>
                                            Coverage
                                        </option>
                                        <option>
                                           druglist
                                        </option>
                                        <option>
                                           copay
                                        </option>
                                        <option>
                                           Messages
                                        </option>
                                        <option>
                                         Pharmacy List
                                        </option>
                                    </Input>
    </Col>
  </FormGroup>
 


</Form>

         
          <Modal.Footer >
            <Button    style={{backgroundColor: "#009BDF" , marginRight:"150px", padding:"10px 40px"}}  onClick={this.closeModal}>
            <b>
            Confirm
              </b>  
            </Button>
          </Modal.Footer>
        </Modal>
            <br/>
             <InputGroup>  
    <FormControl 
     className='mainLoginInput' placeholder=" &#61442; Search by rule menu name"
      aria-label="Recipient's username with two button addons"
    />
    
    <Dropdown as={ButtonGroup}>
  <Button className='search' ><b>Search</b></Button>

  <Dropdown.Toggle className='searchIcon' split variant="primary" id="dropdown-split-basic" />

  <Dropdown.Menu >
  <Dropdown.Item href="#/action-1" onClick={this.openModal}>Add</Dropdown.Item>
    <Dropdown.Item href="#/action-2">Edit</Dropdown.Item>
    <Dropdown.Item href="#/action-3">Delete</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>
  </InputGroup>

            <Card
            >
                <CardBody>

                    <Form>
                    <Table   hover >
  <thead >
    <tr>
    <th></th>
      <th> Name</th>
      <th>Client</th>
      <th>Product</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <Link  to={{  pathname: "/DemoPage",
     state:"messages only",
    }}>Dev Test Menu</Link></td>
      <td>GOOGLE</td>
      <td>coverage</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>Cash Network Test Menu</a></td>
      <td>CASH_NETWORK</td>
      <td>CN Test</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>test</a></td>
      <td>GOOGLE</td>
      <td>coverage</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Test Menu</a></td>
      <td>GOOGLE</td>
      <td>coverage</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Google Test Menu</a></td>
      <td>GOOGLE</td>
      <td>coverage</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>Cash Network 10k Test Menu</a></td>
      <td>CASH_NETWORK</td>
      <td>CN Test 10k</td>
    </tr>
  
 
  
    
    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'>Cash Network 25k Test Menu</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>CASH_NETWORK</td>
      <td>CN Test 25K</td>
    </tr>

    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'> Testing</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>GOOGLE</td>
      <td>coverage</td>
    </tr>
  </tbody>
</Table>
                      
                        </Form>
                        </CardBody>


                        </Card>
            </div>
        )
    }
}
