import React, { Component } from 'react'
import { Tabs, Tab } from 'react-bootstrap';
import Assignment from './Assignments/Assignment';
import RuleMenus from './RuleMenus/RuleMenus';
import Rules from './Rules/Rules';


export default class Coverage extends Component {
  render() {
    return (
      <div>

        <Tabs defaultActiveKey="profile" id="uncontrolled-tab-example" className="mb-3" >
          <Tab eventKey="home" title="Rules">
            <Rules />
          </Tab>
          <Tab eventKey="profile" title="Rule Menus">
            <RuleMenus />
          </Tab>
          <Tab eventKey="contact" title="Assignment" >
            <Assignment />
          </Tab>
        </Tabs>
      </div>
    )
  }
}
