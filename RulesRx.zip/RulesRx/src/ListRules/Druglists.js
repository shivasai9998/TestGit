import React, { Component } from 'react'
import {  Row, Col, FormGroup, Label, Input, Form, Card, CardBody, CardText, CardTitle, CardSubtitle } from 'reactstrap';
import { InputGroup,FormControl ,Button ,Dropdown,ButtonGroup, Table} from 'react-bootstrap';
import './Druglists.css'

export default class Druglists extends Component {
    render() {
        return (
            <div>
          <h2>Rules: Druglists</h2>
            <br/>
             <InputGroup>  
    <FormControl 
     className='mainLoginInput' placeholder=" &#61442; Search by rule menu name"
      aria-label="Recipient's username with two button addons"
    />
    
    <Dropdown as={ButtonGroup}>
  <Button className='search' ><b>Search</b></Button>

  <Dropdown.Toggle className='searchIcon' split variant="primary" id="dropdown-split-basic" />

  <Dropdown.Menu >
    <Dropdown.Item href="#/action-1">Add</Dropdown.Item>
    <Dropdown.Item href="#/action-2">Edit</Dropdown.Item>
    <Dropdown.Item href="#/action-3">Copy</Dropdown.Item>
    <Dropdown.Item href="#/action-4">Delete</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>
  </InputGroup>

            <Card
            >
                <CardBody>

                    <Form>
                    <Table   hover >
  <thead >
    <tr>
    <th></th>
      <th> Name</th>
      <th>Start Date</th>
      <th>End Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>CASH NETWORK DL 105810</a></td>
      <td>1999-01-01</td>
      <td>1999-12-30</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111590</a></td>
      <td>1999-01-01</td>
      <td>2010-06-28</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111590</a></td>
      <td>2010-06-29</td>
      <td>2014-08-06</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111590</a></td>
      <td>2014-08-07</td>
      <td>2017-04-10</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111590</a></td>
      <td>2017-04-11</td>
      <td>2018-09-21</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111694</a></td>
      <td>1999-01-01</td>
      <td>2001-03-12</td>
    </tr>
  
 
  
    
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111694</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>2015-04-16</td>
      <td>2016-07-17</td>
    </tr>

    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111700</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>2015-04-16</td>
      <td>2016-09-21</td>
    </tr>

    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111700</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>2012-01-24</td>
      <td>2014-04-22</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
    <td> <a href='#'>CASH NETWORK DL 111700</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>2017-01-04</td>
      <td>2019-09-21</td>
    </tr>
  </tbody>
</Table>
                      
                        </Form>
                        </CardBody>


                        </Card>
            </div>
        )
    }
}
