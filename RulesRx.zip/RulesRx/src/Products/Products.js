import React, { Component } from 'react'
import {  Row, Col, FormGroup, Label, Input, Form, Card, CardBody, CardText, CardTitle, CardSubtitle } from 'reactstrap';
import { InputGroup,FormControl ,Button ,Dropdown,ButtonGroup, Table} from 'react-bootstrap';
import './Products.css'

export default class Products extends Component {
    render() {
        return (
            <div>
          
            <br/>
             <InputGroup>  
    <FormControl 
     className='mainLoginInput' placeholder=" &#61442; Search by rule product name"
      aria-label="Recipient's username with two button addons"
    />
    
    <Dropdown as={ButtonGroup}>
  <Button className='search' ><b>Search</b></Button>

  <Dropdown.Toggle className='searchIcon' split variant="primary" id="dropdown-split-basic" />

  <Dropdown.Menu >
    <Dropdown.Item href="#/action-1">Add</Dropdown.Item>
    <Dropdown.Item href="#/action-2">Edit</Dropdown.Item>
    <Dropdown.Item href="#/action-3">Delete</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>
  </InputGroup>

            <Card
            >
                <CardBody>

                    <Form>
                    <Table   hover >
  <thead >
    <tr>
    <th></th>
      <th> Name</th>
      <th>Attributes</th>
      <th>Rule Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Dev Test Product</a></td>
      <td>1</td>
      <td></td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>CN Test</a></td>
      <td>33</td>
      <td></td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>Coverage</a></td>
      <td>26</td>
      <td>PBM</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>druglists</a></td>
      <td>33</td>
      <td>LIST</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td> <a href='#'>copay</a></td>
      <td>20</td>
      <td>PBM</td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td>  <a href='#'>Messages</a></td>
      <td>162</td>
      <td>PBM</td>
    </tr>
  
 
  
    
    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'>Pharmacy List</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>0</td>
      <td>LIST</td>
    </tr>

    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'> CN Test 10k</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>33</td>
      <td></td>
    </tr>
    <tr>
    <th><input type="checkbox"  /></th>
      <td ><a href='#'> CN Test 20k</a></td>
      {/* <td colSpan="2">Larry the Bird</td> */}
      <td>40</td>
      <td></td>
    </tr>
  </tbody>
</Table>
                      
                        </Form>
                        </CardBody>


                        </Card>
            </div>
        )
    }
}
