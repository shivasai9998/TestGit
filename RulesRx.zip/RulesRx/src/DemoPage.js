import React, { Component } from 'react';

export default class DemoPage extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         
      }
    }
    
  
  render() {

      console.log("hello sai" , this.props.location.state)

    return <div>

        hello
    </div>;
  }
}
