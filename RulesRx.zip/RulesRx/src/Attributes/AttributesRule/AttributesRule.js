import React, { Component } from 'react'
import { Row, Col, FormGroup, Label, Input, Form, Card, CardBody, CardText, CardTitle, CardSubtitle } from 'reactstrap';
import { InputGroup, FormControl, Button, Dropdown, ButtonGroup, Table } from 'react-bootstrap';
import './AttributesRule.css'


export default class AttributesRule extends Component {
    render() {
        return (
            <div>

                <br />
                <InputGroup>
                    <FormControl
                        className='mainLoginInput' placeholder=" &#61442; Search by attribute name"
                        aria-label="Recipient's username with two button addons"
                    />

                    <Dropdown as={ButtonGroup}>
                        <Button className='search' ><b>Search</b></Button>

                        <Dropdown.Toggle className='searchIcon' split variant="primary" id="dropdown-split-basic" />

                        <Dropdown.Menu >
                            <Dropdown.Item href="#/action-1">Add</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Edit</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Delete</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </InputGroup>

                <Card
                >
                    <CardBody>

                        <Form>
                            <Table hover >
                                <thead >
                                    <tr>
                                        <th></th>
                                        <th> Name</th>
                                        <th>Type</th>
                                        <th>Values</th>
                                        <th>Available To</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td></td>
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>Action_Type</td>
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>Admin_Hold_ind</td>
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>After_Expired_Flag</td>
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>ALT_BNFT_MISC_CDE</td>
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>AMC_Code</td>
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>




                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>AndrewTestAttribute123</td>
                                        {/* <td colSpan="2">Larry the Bird</td> */}
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th><input type="checkbox" /></th>
                                        <td>Approved_Message_Cde</td>
                                        {/* <td colSpan="2">Larry the Bird</td> */}
                                        <td>STRING</td>
                                        <td>
                                            <Input
                                                id="exampleSelect"
                                                name="select"
                                                type="select"
                                            >
                                                <option>

                                                </option>
                                                <option>
                                                    FB
                                                </option>
                                                <option>
                                                    GOOGLE
                                                </option>
                                                <option>
                                                    AMEX
                                                </option>
                                                <option>
                                                    GLOBAL
                                                </option>
                                                <option>
                                                    USNAVY
                                                </option>
                                                <option>
                                                    CASH_NETWORK
                                                </option>
                                            </Input>
                                        </td>
                                    </tr>
                                </tbody>
                            </Table>

                        </Form>
                    </CardBody>


                </Card>
            </div>
        )
    }
}
