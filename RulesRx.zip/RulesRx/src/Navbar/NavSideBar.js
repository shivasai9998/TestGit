import React, { Component } from 'react'
import { FaBars } from "react-icons/fa"
import { AiOutlineClose } from "react-icons/ai";
import { Link } from 'react-router-dom'
import { SideBarData } from './SideBarData';
import './NavSideBar.css'
import { IconContext } from 'react-icons'
import { FaRegUser } from "react-icons/fa";
import { VscSymbolFile } from "react-icons/vsc";
import { GiNetworkBars } from "react-icons/gi";
import { ImEqualizer2 } from "react-icons/im";
import { VscTools } from "react-icons/vsc";
import { IoMdArrowDropdown } from "react-icons/io";

export default class NavSideBar extends Component {
    constructor(props) {
        super(props)

        this.state = {
            sidebar: 'false',
            dropdown1: 'false',
            dropdown2: 'false',
            dropdown3: 'false'
        }
    }

    showSidebar = () => {
        this.setState({ sidebar: !this.state.sidebar })
    }
    render() {

        return (
            <div >
                <IconContext.Provider value={{ color: "white" }}>
                    <div className='navbar'>
                        <Link to="#" className='menu-bars'>
                            <FaBars onClick={this.showSidebar} />
                        </Link>

                    </div>
                    <nav className={this.state.sidebar ? 'nav-menu active' : 'nav-menu'}>
                        <ul className='nav-menu-items' >
                            <li className='navbar-toggle' onClick={this.showSidebar}>
                                <Link to="#" className='menu-bars'>
                                    <AiOutlineClose />
                                </Link>
                            </li>

                            <li className="nav-text" onClick={() => this.setState({ dropdown1: !this.state.dropdown1 })} >
                                <Link to="#" >

                                    <VscTools />
                                    <span>PBM Rules   <IoMdArrowDropdown /></span>
                                </Link>

                            </li>

                            <div class="dropdown1" style={{ display: this.state.dropdown1 ? 'none' : 'block' }}>
                                <li className="nav-text">

                                    <Link to="/" onClick={this.showSidebar}>

                                        <span className='dropColor'> coverage</span>
                                    </Link>
                                    <br /> </li>
                                <li className="nav-text">
                                    <Link to="/" onClick={this.showSidebar}>

                                        <span className='dropColor'>copay</span>
                                    </Link>
                                    <br /> </li>
                                <li className="nav-text">
                                    <Link to="/" onClick={this.showSidebar}>

                                        <span className='dropColor'>Messages</span>
                                    </Link>
                                    <br /> </li>

                            </div>


                            <li className="nav-text" onClick={() => this.setState({ dropdown2: !this.state.dropdown2 })} >
                                <Link to="#">
                                    <VscTools />
                                    <span>List Rules  <IoMdArrowDropdown /></span>
                                </Link>
                            </li>

                            <div class="dropdown1" style={{ display: this.state.dropdown2 ? 'none' : 'block' }}>
                                <li className="nav-text">

                                    <Link to="/Druglists" onClick={this.showSidebar}>

                                        <span className='dropColor'> Druglists</span>
                                    </Link>
                                    <br /> </li>
                                <li className="nav-text">
                                    <Link to="/Druglists" onClick={this.showSidebar}>

                                        <span className='dropColor'>Pharmacy List</span>
                                    </Link>
                                     </li>
                            </div>


                            <li className="nav-text"  onClick={() => this.setState({ dropdown3: !this.state.dropdown3 })} >
                                <Link to="#">
                                    <VscSymbolFile />
                                    <span>Attributes  <IoMdArrowDropdown /></span>
                                </Link>
                            </li>

                            <div class="dropdown1" style={{ display: this.state.dropdown3 ? 'none' : 'block' }}>
                                <li className="nav-text">

                                    <Link to="/AttributesRule" onClick={this.showSidebar}>

                                        <span className='dropColor'> Rule</span>
                                    </Link>
                                    <br /> </li>
                                <li className="nav-text">
                                    <Link to="/AttributesRule" onClick={this.showSidebar}>

                                        <span className='dropColor'> Result</span>
                                    </Link>
                                     </li>
                            </div>
                            <li className="nav-text" >
                                <Link to="/Products" onClick={this.showSidebar}>
                                    <ImEqualizer2 />
                                    <span>Products</span>
                                </Link>
                            </li>
                            <li className="nav-text" >
                                <Link to="/Result" onClick={this.showSidebar}>
                                    <GiNetworkBars />
                                    <span>Results</span>
                                </Link>
                            </li>

                            {/* {SideBarData.map((item, index) => {
                                return (
                                    <li key={index} className={item.cName}>
                                        <Link to={item.path}>
                                            {item.icon}
                                            <span>{item.title}</span>
                                        </Link>
                                    </li>
                                )
                            })} */}




                            <div className='BottomUserIcon'>
                                <li className="nav-text" >
                                    <Link to="/Contact" >
                                        <FaRegUser />
                                        <span>User</span>
                                    </Link>
                                </li>
                            </div>
                        </ul>
                    </nav>
                </IconContext.Provider>
            </div>
        )
    }
}




