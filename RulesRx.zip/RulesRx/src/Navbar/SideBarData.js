import React from 'react';
import SideNav, { Toggle, Nav, NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';
import '@trendmicro/react-sidenav/dist/react-sidenav.css';
import { VscTools } from "react-icons/vsc";
import { VscSymbolFile } from "react-icons/vsc";
import { ImEqualizer2 } from "react-icons/im";
import { GiNetworkBars } from "react-icons/gi";
import { FaRegUser } from "react-icons/fa";
import './NavSideBar.css'
import { Link } from 'react-router-dom'

function SideBarData() {
  return <div>

<SideNav
    onSelect={(selected) => {
        // Add your code here
    }}
    style={{background:"#009bdf"}}
>
    <SideNav.Toggle />
    <SideNav.Nav >
        <NavItem eventKey="home">
            <NavIcon>
                {/* <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} /> */}
                <VscTools />
            </NavIcon>
            <NavText>
            PBM Rules
            </NavText>
            <NavItem eventKey="charts/linechart">
                <NavText>
                <Link to="/" style={{ textDecoration: 'none', color:"black" }} >
                coverage
              
        
              </Link>
                </NavText>
            </NavItem>
            <NavItem eventKey="charts/linechart">
                <NavText>
                <Link to="/" style={{ textDecoration: 'none' , color:"black"}} >
                copay
              
        
              </Link>
                </NavText>
            </NavItem>
            <NavItem eventKey="charts/linechart">
                <NavText>
                <Link to="/" style={{ textDecoration: 'none' , color:"black"}} >
                Messages
          </Link>
                
                </NavText>
            </NavItem>
        </NavItem>
      
        <NavItem eventKey="List_Rules">
            <NavIcon>
            <VscTools />
                {/* <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} /> */}
            </NavIcon>
            <NavText>
            List Rules
            </NavText>
            <NavItem eventKey="charts/linechart">
                <NavText>
                <Link to="/Druglists" style={{ textDecoration: 'none', color:"black" }} >
                Druglists
           
          
          </Link>
                </NavText>
            </NavItem>
            <NavItem eventKey="charts/barchart">
                <NavText>
                <Link to="/Druglists" style={{ textDecoration: 'none', color:"black" }} >
                Pharmacy List
               
          
          </Link>

                </NavText>
            </NavItem>
        </NavItem>
        <NavItem eventKey="Attributes">
            <NavIcon>
                {/* <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} /> */}
                <VscSymbolFile />
            </NavIcon>
            <NavText>
            Attributes
            </NavText>
            <NavItem eventKey="charts/linechart">
                <NavText>
                <Link to="/AttributesRule" style={{ textDecoration: 'none', color:"black" }} >
                Rule
          
          </Link>
                </NavText>
            </NavItem>
            <NavItem eventKey="charts/barchart">
                <NavText>
                <Link to="/AttributesRule" style={{ textDecoration: 'none', color:"black" }} >
                Result
          
          </Link>
                </NavText>
            </NavItem>
        </NavItem>
        <NavItem eventKey="Products">
            <NavIcon>
                {/* <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} /> */}
                <Link to="/Products" style={{ textDecoration: 'none' }} >
           
                <ImEqualizer2 />
           </Link>
            </NavIcon>
            <NavText>
            <Link to="/Products" style={{ textDecoration: 'none' }} >
            Products
          
           </Link>
            </NavText>
           
           
        </NavItem>
        <NavItem eventKey="Results">
            <NavIcon>
                {/* <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} /> */}
                <Link to="/Result" style={{ textDecoration: 'none' }} >
           
                <GiNetworkBars />
          
           </Link>
            </NavIcon>
            <NavText>

            <Link to="/Result" style={{ textDecoration: 'none' }} >
           
            Results
          
           </Link>
            </NavText>
          
           
        </NavItem>
            
     
        <NavItem eventKey="User" style={{position:"absolute",width:"100%",bottom:"0%"}}>
            <NavIcon>
                {/* <i className="fa fa-fw fa-line-chart" style={{ fontSize: '1.75em' }} /> */}
                <Link to="/Contact" style={{ textDecoration: 'none' }} >
          
                <FaRegUser />
           </Link>
            </NavIcon>
            <NavText>
        <Link to="/Contact" style={{ textDecoration: 'none' }} >
            User
           </Link>
           
            </NavText>
          
        </NavItem>
    </SideNav.Nav>
</SideNav>
  </div>;
}

export default SideBarData;
