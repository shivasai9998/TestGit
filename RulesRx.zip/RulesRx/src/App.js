import React, { Component } from 'react'
import Routes1 from './Routes1'



export default class App extends Component {
  render() {
    return (
      <div>
        <Routes1 />
      </div>
    )
  }
}
